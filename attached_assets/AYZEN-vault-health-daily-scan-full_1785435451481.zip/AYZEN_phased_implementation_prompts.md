# AYZEN — Vault / Project / Team Overhaul — Phased Prompts

Phases 1–6 are numbered as originally planned. From Phase 7 onward, every phase has
been split into an **A** and **B** part, each sized to fit in **one AI coding session**
(23 phases total). Each phase below is **self-contained** — copy just that phase's
block (including its "Depends on"/"Touches" line) into a fresh session; you don't need
to paste earlier phases. Do them in order — later phases assume earlier ones (including
the A part of their own letter-pair) are already merged into the codebase (dependency
noted per phase).

Stack recap (put this once at the top of every session if your tool doesn't keep it):
*Python FastAPI backend, Vite/React frontend in `artifacts/ayzen/src`, shadcn/ui,
Supabase Postgres + RLS, Redis, Telegram bot. Reuse existing components/hooks/API
patterns — do not introduce a second styling or data-fetching convention. Mobile-first;
test at narrow width.*

---

## PHASE 1 — Vault Entity: visible card details + richer quick view
**Depends on:** nothing. **Touches:** `pages/user/vault.tsx`

**Context:** Entity cards in the vault list currently reveal almost nothing until
clicked; clicking opens a quick-view dialog showing credential name only.

**Do:**
1. On each entity card (no click needed), show: entity name, platform-presence icons
   (Twitter/Discord/Telegram/Wallet/Other — whichever the entity has configured), a
   buy-value vs worth badge, and enrolled-project count.
2. Expand the click-triggered quick view beyond name-only: add platform
   handles/usernames, status flags, buy value vs worth, short enrollment summary.
3. **Do not** add passwords, seed phrases, 2FA secrets, or backup codes to either the
   card or the quick view — those stay behind the existing PIN/unlock gate flow, reached
   only via "View Full Details."

**Acceptance:** card grid shows the above without a click; quick-view dialog shows
materially more than today while still hiding all secrets; "View Full Details" button
still navigates to `vault-entity-detail.tsx` unchanged.

---

## PHASE 2 — Vault Entity: unified "Access" page (2FA / Mail / Backup)
**Depends on:** Phase 1 (not required, but logically next). **Touches:**
`pages/user/vault-entity-detail.tsx`, new route e.g. `/vault/entity/:id/access`, reusing
logic from `pages/user/vault-2fa-entity.tsx`, `pages/user/vault-mail.tsx` +
`vault-mail-inbox.tsx` + `vault-mail-message*.tsx`, `pages/user/vault-backup.tsx`.

**Context:** `vault-entity-detail.tsx` has tabs `dashboard/overview/credentials/twitter/
discord/telegram/wallet/other`. 2FA, Mail, and Backup currently live in separate,
not-fully-entity-scoped pages.

**Do:**
1. Add an **"Access"** button on `vault-entity-detail.tsx` (separate from the existing
   tab bar).
2. Clicking navigates to a new full-page route scoped to that single entity, with 3
   tabs: **2FA**, **Mail**, **Backup**.
   - 2FA tab: reuse `vault-2fa-entity.tsx` / `totp-card.tsx` logic, filtered to this
     entity's TOTP secrets only.
   - Mail tab: reuse the vault-mail components, but list **all email accounts belonging
     to this entity** (an entity can have more than one mailbox) — not the global inbox.
   - Backup tab: reuse `vault-backup.tsx`, filtered to this entity's backup/recovery
     codes.
3. Keep the existing PIN-gate / unlock-gate (`entity-pin-gate.tsx`,
   `vault-unlock-gate.tsx`) protecting this page exactly as elsewhere.

**Acceptance:** Access page only reachable from an entity's full-detail page; all 3 tabs
correctly filtered to one `vaultEntryId`; no cross-entity leakage; gates still enforced.

---

## PHASE 3 — Project description field
**Depends on:** nothing. **Touches:** `pages/admin/projects.tsx`,
`pages/admin/project-detail.tsx`, `pages/user/projects.tsx` (display only).

**Do:** Add a `description` textarea to the admin project create/edit form if not
already present; persist it; confirm it renders on the project card (`projects.tsx`
already reads `project.description` — just confirm the round-trip from admin works).

**Acceptance:** creating/editing a project from admin sets description; value shows on
the project card and detail page after save.

---

## PHASE 4 — Project activity log (enrollment / days worked / rewards)
**Depends on:** nothing (but Phase 13/15 will reuse this schema — see note at bottom).
**Touches:** backend log table/endpoint, `pages/user/project-entities.tsx`,
`entity-dashboard-tabs.tsx` (Project tab), new project-dashboard page (built in Phase 9).

**Do:** Build a log capturing, per entity↔project enrollment: `enrolled_at`,
`joined_at`, `left_at`, cumulative days active, and reward events (timestamp, amount,
running total). Design the table generically — `activity_log` with
`subject_type`/`subject_id` — so Phase 15 (team activity log) can reuse it instead of a
second bespoke table. Render as a table/timeline on: (a) the project's own dashboard
(aggregate, built in Phase 9), and (b) the entity's Project tab in
`entity-dashboard-tabs.tsx`.

**Acceptance:** every enroll/join/leave/reward action writes a log row; totals (days
active, total reward, reward/day) are computed from the log, not stored out-of-sync;
schema is generic enough for non-project subjects.

---

## PHASE 5 — Disqualify / ban / cancel enrollment
**Depends on:** Phase 4 (writes to its log). **Touches:**
`pages/user/project-entities.tsx`, admin project-detail equivalent.

**Do:** Add per-entity actions on the enrolled-entities view: **Disqualify** (stops
future reward accrual, keeps history), **Ban** (disqualify + blocks re-enrollment in
this project), **Cancel enrollment** (voluntary/admin removal, no stigma, can
re-enroll). Each writes to the Phase 4 log (who/when/why) and updates status visibly in
both user and admin views.

**Acceptance:** all 3 actions available to admin/moderator; status changes reflect
immediately; disqualified/banned entities are visually distinguished in lists.

---

## PHASE 6 — Project comparison view
**Depends on:** Phase 3 and Phase 7 (badges) for full field coverage, but can ship with
just Phase 3. **Touches:** `pages/user/projects.tsx`, new compare view/route.

**Do:** Allow selecting 2–3 projects (checkboxes or a "Compare" action on the list) and
show a side-by-side view: stats, reward structure, requirements, enrolled-entity count,
tier/category/badges, description. Read-only — no enrollment actions from this view.

**Acceptance:** works for exactly 2 or 3 selections; deselecting returns to normal list.

---

## PHASE 7A — Project badge/tag system: data model + admin authoring
**Depends on:** Phase 3 (shares the admin form). **Touches:** backend project
schema/migration, `pages/admin/projects.tsx`.

**Do:**
1. Add a `badges`/`tags` field to the project record (string list) — migration + API
   schema update.
2. In the admin project create/edit form, add a tag-input control next to the
   description field: add/remove badges, persist on save.
3. Confirm round-trip: reload the admin form after save and the badges are
   pre-populated correctly.

**Acceptance:** badges are persisted server-side; admin can add/remove/save them;
reopening the edit form shows the saved badges. (No consumer-facing rendering yet —
that's 7B.)

---

## PHASE 7B — Project badge/tag system: consumer rendering
**Depends on:** Phase 7A (needs the data field to exist), Phase 6 (compare view must
already exist). **Touches:** `pages/user/projects.tsx`, `pages/user/project-detail.tsx`,
`pages/user/project-compare.tsx`.

**Do:**
1. Render the badges from 7A consistently in three places, reusing one shared
   badge-list component/pattern rather than three separate implementations:
   - Project cards in `projects.tsx`
   - Project detail page
   - Compare view (`project-compare.tsx`, added in Phase 6) — as its own comparison row
2. Empty badge list → render nothing (no empty badge row/placeholder).

**Acceptance:** badges render identically (same styling, same order) across list,
detail, and compare; a project with zero badges shows cleanly with no broken layout.

---

## PHASE 8A — Tutorial step "full details" toggle: authoring
**Depends on:** nothing. **Touches:** the tutorial/submission-guide builder UI (locate
under admin or `project-detail.tsx`'s guide/submission-guide section), backend step
schema.

**Do:** Per tutorial step, add an optional "full step details" field/toggle at authoring
time — extra content (longer text/images/sub-steps), off by default. Persist alongside
the existing step data.

**Acceptance:** author can enable the toggle per step and fill in the extra content;
saving/reloading the builder preserves it; steps left off are unaffected.

---

## PHASE 8B — Tutorial step "full details" toggle: consumer render
**Depends on:** Phase 8A (needs the data field). **Touches:** the consumer-facing
tutorial/submission-guide render.

**Do:** Steps with the toggle enabled (from 8A) show an expand/collapse control in the
consumer view; expanding reveals the extra content (long text/images/sub-steps),
collapsed by default. Steps without it render exactly as today.

**Acceptance:** steps left off in 8A render unchanged; steps with it on show a working
expand/collapse control revealing the extra content.

---

## PHASE 9A — Enroll sidebar shell + Projects Overview
**Depends on:** Phase 4 (log data feeds the Overview stats). **Touches:** new
`components/layout/enroll-sidebar.tsx` (modeled on `vault-sidebar.tsx`), new
Projects-overview route.

**Do:**
1. Build an Enroll sidebar with two sections: **Projects**, **Entities** (Entities
   wired up in Phase 10; leave as an empty/placeholder section link for now).
2. Projects section has an **Overview** (8–9 stat widgets: pie chart, bar chart(s), and
   a heatmap-style visualization of enrollment/activity — use whatever chart library is
   already a dependency in `artifacts/ayzen/package.json`) and a **Project list**.

**Acceptance:** sidebar renders with Projects/Entities sections; Overview/list toggle
works within Projects; stat widgets are populated from Phase 4 log data, not mocked.

---

## PHASE 9B — Per-project dedicated dashboard page
**Depends on:** Phase 9A (sidebar + project list must exist), Phase 4 (activity log),
Phase 5 (moderation actions). **Touches:** new per-project dashboard route (separate
from `project-detail.tsx`'s submission flow).

**Do:** Each project in the 9A list is clickable and opens its **own dedicated
dashboard page** (own URL, deep-linkable) showing that project's stats, enrolled
entities, the Phase 4 activity log, and the Phase 5 moderation actions — separate from
the submission-flow `project-detail.tsx`.

**Acceptance:** every project has a deep-linkable dashboard URL independent of the
submission flow; activity log and moderation actions both work from this page.

---

## PHASE 10A — Enroll: Entities Overview + list
**Depends on:** Phase 9A (sidebar shell must exist), Phase 1/2 (entity data shapes).
**Touches:** Enroll sidebar's Entities section.

**Do:** Mirror Phase 9A for entities: fill in the Entities section with an Overview
(aggregate dashboard across the user's entities: stat widgets/charts mirroring the
Projects Overview pattern) and an Entity list.

**Acceptance:** same Overview+list pattern as Phase 9A, under the Entities section;
Overview stats reflect real entity data.

---

## PHASE 10B — Enroll: entity dedicated dashboard
**Depends on:** Phase 10A (entity list must exist). **Touches:** Enroll sidebar's
Entities section, reusing `entity-dashboard-tabs.tsx`.

**Do:** Each entity in the 10A list opens its dedicated dashboard — reuse the existing
`EntityDashboardTabs` component (the same one used by `vault-entity-detail.tsx`
"dashboard" tab) rather than building a second dashboard implementation.

**Acceptance:** every entity has a deep-linkable dashboard; zero duplicate dashboard
code — confirmed reuse of `EntityDashboardTabs`.

---

## PHASE 11A — Team sidebar shell (routing skeleton)
**Depends on:** nothing new (pure relocation). **Touches:** `pages/user/teams.tsx`.

**Do:** Build the hierarchical sidebar with 4 top-level sections — **Overview**,
**Task**, **App**, **Other** — as empty/placeholder containers with working routing/
navigation. Do not move any tab content yet.

**Acceptance:** new 4-section sidebar renders and navigates between empty placeholder
sections; old flat tab list still exists/works untouched (not yet removed).

---

## PHASE 11B — Team sidebar: map old tabs into new sections
**Depends on:** Phase 11A (sections must exist). **Touches:** `pages/user/teams.tsx`.

**Do:** Map old tabs into the 11A sections without deleting any logic yet:
`missions+tasks`→Task, `vault+projects`→App, `members+invite+chat/panel`→Other,
`dashboard`→Overview, `leaderboard/browse`→handled specially in Phase 12. This is a
temporary nesting — full content relocation/cleanup happens in Phases 12–15.

**Acceptance:** every old tab's feature is reachable from inside its new section (even
if temporarily nested oddly); nothing is deleted; old flat tab list can now be removed
since all content has a new home.

---

## PHASE 12A — Team Overview: browse/join/create (non-member state)
**Depends on:** Phase 11B. **Touches:** Overview section of `teams.tsx`, reusing the
existing `browse` tab.

**Do:** If the user is **not in a team**, Overview shows a team browser — search by team
username (add a unique username/handle field to teams if not present) — with join/create
actions, based on the existing `browse` tab logic.

**Acceptance:** non-member state renders the browser; username field is searchable;
join/create actions work and result in team membership.

---

## PHASE 12B — Team Overview: scoped dashboard + Leave/Leaderboard (member state)
**Depends on:** Phase 12A (membership must be achievable). **Touches:** Overview
section of `teams.tsx`, reusing `TeamLeaderboard` component.

**Do:** Once the user **joins or creates** a team, Overview **replaces itself** with
that team's scoped dashboard. Scoped Overview has, top corner: a **Leave** button and a
**Leaderboard** button (reuses `TeamLeaderboard`/existing `leaderboard` tab logic,
surfaced here instead of as its own top-level tab).

**Acceptance:** member state is a distinct render gated on membership; Leave reverts to
the 12A browse state; Leaderboard button opens the existing leaderboard view.

---

## PHASE 13A — Team App section: Vault + Project relocation
**Depends on:** Phase 11B. **Touches:** App section of `teams.tsx`, reusing existing
`vault`/`projects` team tabs.

**Do:** App section = **Vault** (existing team `vault` tab, unchanged) + **Project**
(existing team `projects` tab, unchanged) as two sub-views. Pure relocation, no
reimplementation.

**Acceptance:** Vault/Project sub-views work exactly as before, just relocated under
App.

---

## PHASE 13B — Team App section: team mail
**Depends on:** Phase 13A (App section must exist), Phase 2 (vault-mail patterns to
reuse). **Touches:** App section of `teams.tsx`, new team-mail sub-view based on
`vault-mail.tsx` patterns.

**Do:** Add a new **mail** sub-view scoped to the team's AYZEN-provided mailbox
(distinct from per-entity vault mail — Phase 2) — reuse vault-mail component patterns
but point them at the team-level mailbox/API.

**Acceptance:** team mail sub-view lists the team mailbox and never mixes with
entity-scoped vault mail.

---

## PHASE 14A — Team Task section: Task sub-view
**Depends on:** Phase 11B. **Touches:** Task section of `teams.tsx`, reusing the
existing `tasks` tab.

**Do:** Relocate the existing `tasks` tab under the new Task section as a sub-view. No
reimplementation — pure relocation.

**Acceptance:** Task sub-view functions identically to the old tab, just nested under
Task.

---

## PHASE 14B — Team Task section: Mission sub-view
**Depends on:** Phase 14A (Task section must exist). **Touches:** Task section of
`teams.tsx`, reusing the existing `missions` tab.

**Do:** Relocate the existing `missions` tab under the Task section as a second
sub-view, alongside 14A's Task sub-view. No reimplementation — pure relocation.

**Acceptance:** Mission sub-view functions identically to the old tab, just nested
under Task, alongside the Task sub-view from 14A.

---

## PHASE 15A — Team Other section: Members + Invite
**Depends on:** Phase 11B. **Touches:** Other section of `teams.tsx`, reusing
`members`/`invite` tabs.

**Do:**
1. **Members** sub-view: reuse existing `members` tab, but also surface each member's
   progress (task/mission completion, vault-activity contribution) — not just a static
   roster.
2. **Invite** sub-view: reuse existing `invite` tab unchanged.

**Acceptance:** Members shows live progress per member; Invite sub-view works exactly
as the old tab, just relocated.

---

## PHASE 15B — Team Other section: Activity log
**Depends on:** Phase 15A (Other section must exist), Phase 4 (shared activity-log
schema). **Touches:** Other section of `teams.tsx`, new team activity-log view.

**Do:** **Activity log** sub-view: chronological feed of team-level actions — who did
what, when — explicitly including vault-usage events (which member accessed/used which
vault entity, when). Use the **same generic `activity_log` table** built in Phase 4
(`subject_type`/`subject_id`) rather than a second logging system.

**Acceptance:** activity log includes vault-usage entries, attributed and timestamped,
sourced from the shared log table, alongside the Members/Invite sub-views from 15A.

---

## Status
- **Phase 6 — merged & committed.** (`/projects/compare` route, compare checkboxes +
  floating compare bar on `projects.tsx`, new `project-compare.tsx`.)
- **Phase 9A — merged & committed.** New `components/layout/enroll-sidebar.tsx`
  (Projects/Entities sections, modeled on `vault-sidebar.tsx`) + `/enroll/projects`
  (Overview/Project-List tabs) and `/enroll/entities` (Phase 10A placeholder) routes,
  linked from a new "Enroll" group in `app-sidebar.tsx`'s USER_NAV. Backend:
  `GET /projects/mine/overview` (`lib/activity-log.ts#getUserEnrollmentsOverview`)
  aggregates every project_enrollment's activity_log rows into 9 stat widgets, a
  status pie chart, two bar charts (reward-by-project, enrollments-over-time), and a
  365-day activity heatmap — all computed from the log at read time, nothing stored.
  Also extracted the private heatmap in `project-detail.tsx` into a shared
  `components/data-activity-heatmap.tsx` (`DataActivityHeatmap`) so both pages render
  identically instead of duplicating the grid logic.

## Suggested session grouping (if you want to batch phases)
- **Session block 1 (Vault):** Phases 1–2
- **Session block 2 (Projects — data/moderation):** Phases 3–5
- **Session block 3 (Projects — discovery):** Phase 6 ✅ done, Phases 7A–7B
- **Session block 4 (Tutorial):** Phases 8A–8B (small, can tack onto block 3)
- **Session block 5 (Enroll dashboards):** Phases 9A–9B, 10A–10B
- **Session block 6 (Team shell + Overview):** Phases 11A–11B, 12A–12B
- **Session block 7 (Team App + Task):** Phases 13A–13B, 14A–14B
- **Session block 8 (Team Other/Social):** Phases 15A–15B

Each individual phase (A or B) is small enough to run standalone if you'd rather do all
of them one-by-one — that's now 23 phases total instead of 15, each roughly half the
size of the original.
